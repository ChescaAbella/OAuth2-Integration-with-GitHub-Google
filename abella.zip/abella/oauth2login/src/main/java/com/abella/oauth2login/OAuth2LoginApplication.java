package com.abella.oauth2login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuth2LoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuth2LoginApplication.class, args);
	}

}
