package com.abella.oauth2login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OAuth2LoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
